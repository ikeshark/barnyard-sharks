import React from 'react';

const MyTop12 = ({ top12 }) => {
  return (
    <ul>
      <li>song 1</li>
      <li>song 2</li>
      <li>song 3</li>
      <li>song 4</li>
    </ul>
  );
}
