import React from 'react';

const SongList = ({
  detailedSong,
  onClick,
  songs,
  className = "songList"
  }) => (
  <ul className={className}>
    {songs.map(song => (
      <li key={song.name}>
        <button
          onClick={onClick}
          className={detailedSong === song ? "active" : ""}
        >
          {song.name}
        </button>
      </li>
    ))}
  </ul>
);

export default SongList;
